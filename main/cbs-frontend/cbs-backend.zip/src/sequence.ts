import {MiddlewareSequence} from '@loopback/rest';

export class MySequence extends MiddlewareSequence {}
