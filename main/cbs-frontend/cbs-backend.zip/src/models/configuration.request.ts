export class ConfigurationRequest {
  value: string;


  constructor() {
  }
}
