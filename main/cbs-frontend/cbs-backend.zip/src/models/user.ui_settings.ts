
export class UserUISettingsRequest {
  ui_settings: string;

  constructor() {
  }
}
