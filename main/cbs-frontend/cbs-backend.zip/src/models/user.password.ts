export class UserPasswordUpdateRequest {
  old_password?: string;
  new_password: string;

  constructor() {
  }
}
